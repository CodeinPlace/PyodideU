from js import jsgraphics
from pyodide import create_proxy
import unthrow




def create_canvas(wid, hei):
    cc_count=jsgraphics.getCreateCanvasCount()
    if cc_count > 1:
        raise Exception("create_canvas called more than once")
    return Canvas(wid, hei)

class Canvas:

    DEFAULT_WIDTH = 400
    """The default width of the canvas is 400."""

    DEFAULT_HEIGHT = 400
    """The default height of the canvas is 400."""

    DEFAULT_TITLE = "Canvas"

    def __init__(self, width=DEFAULT_WIDTH, height=DEFAULT_HEIGHT, title=DEFAULT_TITLE):
        self.canvas = None
        try:
            self.canvas = jsgraphics.create_canvas(width, height)
        except Exception as e:
            raise Exception("Error creating canvas: Make sure you are in a Graphics project.")

    def set_canvas_background_color(self, color):
        self.__assert_param(color, [str], "color", "set_canvas_background_color")
        return self.canvas.set_canvas_background_color()

    def get_canvas_background_color(self, color):
        self.__assert_param(color, [str], "color", "get_canvas_background_color")
        return self.canvas.get_canvas_background_color()


    def get_width(self):
        return self.canvas.get_width()

    def get_height(self):
        return self.canvas.get_height()

    def create_line(self, x1, y1, x2, y2, color="black"):
        self.__assert_param(x1, [float, int], "x1", "create_line")
        self.__assert_param(y1, [float, int], "y1", "create_line")
        self.__assert_param(x2, [float, int], "x2", "create_line")
        self.__assert_param(y2, [float, int], "y2", "create_line")
        self.__assert_param(color, [str], "color", "create_line")

        return self.canvas.create_line(x1, y1, x2, y2, color)

    def create_rectangle(self, leftX, topY, rightX, bottomY, color = "black", outline="TRANSPARENT"):
        self.__assert_param(leftX, [float, int], "leftX", "create_rectangle")
        self.__assert_param(topY, [float, int], "topY", "create_rectangle")
        self.__assert_param(rightX, [float, int], "rightX", "create_rectangle")
        self.__assert_param(bottomY, [float, int], "bottomY", "create_rectangle")
        self.__assert_param(color, [str], "color", "create_rectangle")
        self.__assert_param(outline, [str], "outline", "create_rectangle")


        return self.canvas.create_rectangle(leftX, topY, rightX, bottomY, color, outline)

    def create_oval(self, x1, y1, x2, y2, color="black", outline="TRANSPARENT"):
        self.__assert_param(x1, [float, int], "x1", "create_oval")
        self.__assert_param(y1, [float, int], "y1", "create_oval")
        self.__assert_param(x2, [float, int], "x2", "create_oval")
        self.__assert_param(y2, [float, int], "y2", "create_oval")
        self.__assert_param(color, [str], "color", "create_oval")
        self.__assert_param(outline, [str], "outline", "create_oval")

        return self.canvas.create_oval(x1, y1, x2, y2, color, outline)

    def set_on_click(self, callback, *args):

        return self.canvas.set_on_click(callback, *args)

    def create_image(self, x, y, filePath):
        self.__assert_param(x, [float, int], "x", "create_image")
        self.__assert_param(y, [float, int], "y", "create_image")
        self.__assert_param(filePath, [str], "filePath", "create_image")

        return self.canvas.create_image(x, y, filePath)

    def create_image_with_size(self, x, y, width, height, filePath):
        self.__assert_param(x, [float, int], "x", "create_image_with_size")
        self.__assert_param(y, [float, int], "y", "create_image_with_size")
        self.__assert_param(filePath, [str], "filePath", "create_image_with_size")
        self.__assert_param(width, [float, int], "width", "create_image_with_size")
        self.__assert_param(height, [float, int], "height", "create_image_with_size")

        return self.canvas.create_image_with_size(x, y, width, height, filePath)

    # What is anchor
    def create_text(self, x, y, text, font="Arial", font_size="12px", color="BLACK", anchor="NW"):
        self.__assert_param(text, [str], "text", "create_text")
        self.__assert_param(x, [float, int], "x", "create_text")
        self.__assert_param(y, [float, int], "y", "create_text")
        self.__assert_param(font_size, [str, int], "font_size", "create_text")
        self.__assert_param(font, [str], "font_type", "create_text")
        self.__assert_param(color, [str], "font_color", "create_text")
        if type(font_size) == int:
            font_size = str(font_size) + "px"

        return self.canvas.create_text(x, y, text, font, font_size, color, anchor)

    def delete(self, objectId):
        self.__assert_param(objectId, [str], "objectId", "delete")

        return self.canvas.delete(objectId)

    def clear(self):
        return self.canvas.clear()

    def find_overlapping(self, leftX, topY, rightX, bottomY):
        self.__assert_param(leftX, [float, int], "leftX", "find_overlapping")
        self.__assert_param(topY, [float, int], "topY", "find_overlapping")
        self.__assert_param(rightX, [float, int], "rightX", "find_overlapping")
        self.__assert_param(bottomY, [float, int], "bottomY", "find_overlapping")
        return self.canvas.find_overlapping(leftX, topY, rightX, bottomY).to_py()

    def get_mouse_x(self):
        return self.canvas.get_mouse_x()

    def get_mouse_y(self):
        return self.canvas.get_mouse_y()

    def get_last_click(self):
        return self.canvas.get_last_click()

    def get_last_key_press(self):
        return self.canvas.get_last_key_press()

    def sleep(self, delta):
        self.__assert_param(delta, [int, float], "delta", "sleep")
        return self.canvas.sleep(delta)

    def move(self, objectId, dx, dy):
        self.__assert_param(objectId, [str], "objectId", "move")
        self.__assert_param(dx, [int, float], "dx", "move")
        self.__assert_param(dy, [int, float], "dy", "move")
        return self.canvas.move(objectId, dx, dy)

    def moveto(self, objectId, newX, newY):
        self.__assert_param(objectId, [str], "objectId", "moveto")
        self.__assert_param(newX, [int, float], "newX", "moveto")
        self.__assert_param(newY, [int, float], "newY", "moveto")

        return self.canvas.moveto(objectId, newX, newY)

    def get_left_x(self, objectId):
        self.__assert_param(objectId, [str], "objectId", "get_left_x")

        return self.canvas.get_left_x(objectId)

    def get_top_y(self, objectId):
        self.__assert_param(objectId, [str], "objectId", "get_top_y")

        return self.canvas.get_top_y(objectId)

    def get_x(self, objectId):
        self.__assert_param(objectId, [str], "objectId", "get_x")

        return self.canvas.get_x(objectId)

    def get_y(self, objectId):
        self.__assert_param(objectId, [str], "objectId", "get_y")

        return self.canvas.get_y(objectId)

    def get_object_width(self, objectId):
        self.__assert_param(objectId, [str], "objectId", "get_object_width")

        return self.canvas.get_object_width(objectId)

    def get_object_height(self, objectId):
        self.__assert_param(objectId, [str], "objectId", "get_object_height")

        return self.canvas.get_object_height(objectId)

    def mainloop(self):
        return self.canvas.mainloop()

    def set_hidden(self, objectId, is_hidden):
        self.__assert_param(objectId, [str], "objectId", "set_hidden")
        self.__assert_param(is_hidden, [bool], "is_hidden", "set_hidden")
        return self.canvas.set_hidden(objectId,is_hidden)

    def set_color(self, objectId, color):
        self.__assert_param(objectId, [str], "objectId", "set_color")
        self.__assert_param(color, [str], "color", "set_color")
        return self.canvas.set_color(objectId, color)

    def set_outline_color(self, objectId, color):
        self.__assert_param(objectId, [str], "objectId", "set_outline_color")
        self.__assert_param(color, [str], "color", "set_outline_color")
        return self.canvas.set_outline_color(objectId, color)

    def wait_for_click(self):
        unthrow.cip___awaitclick()
        return

    def change_text(self, objectId, new_text):
        self.__assert_param(objectId, [str], "objectId", "change_text")
        self.__assert_param(new_text, [str], "new_text", "change_text")
        return self.canvas.change_text(objectId, new_text)

    def create_polygon(self, *args, color="BLACK", outline="TRANSPARENT"):
        # Extract the options, if any
        if len(args) % 2 != 0:
            raise ValueError("Coordinates must be provided in pairs.")

        # Process the coordinates
        assert all(isinstance(element, (int, float)) for element in args), "Some coordinates are incorrect types. Accepted types include: int, float."

        # Create your polygon using the coordinates and options
        # Replace the print statement with your polygon creation logic
        return self.canvas.create_polygon(create_proxy(args), color, outline)

    def get_new_mouse_clicks(self):
        return self.canvas.get_new_mouse_clicks()

    def get_new_key_presses(self):
        return self.canvas.get_new_key_presses()

    def coords(self, objectId):
        self.__assert_param(objectId, [str], "objectId", "coords")
        return self.canvas.coords(objectId)


    # def create_button(self, title, location):
    #     self.__assert_param(title, [str], "title", "create_button")
    #     self.__assert_param(location, [str], "location", "create_button")
    #     return self.canvas.create_button(title, location)

    # def get_new_button_clicks(self):
    #     return self.canvas.get_new_button_clicks()

    # def create_text_field(self, label, location):
    #     self.__assert_param(label, [str], "label", "create_text_field")
    #     self.__assert_param(location, [str], "location", "create_text_field")
    #     return self.canvas.create_text_field(label, location)

    # def delete_text_field(self, text_field_name):
    #     self.__assert_param(text_field_name, [str], "text_field_name", "delete_text_field")
    #     return self.canvas.delete_text_field(text_field_name)


    # def get_text_field_text(self, text_field_name):
    #     self.__assert_param(text_field_name, [str], "text_field_name", "get_text_field_text")
    #     return self.canvas.get_text_field_text(text_field_name)

    def __assert_param(self, var, var_types, param_name, function_name):
        assert type(var) in var_types , param_name + " should be one of the following types: " + ', '.join([x.__name__ for x in var_types]) +  " in function " + function_name + ". Recieved " + type(var).__name__ + " instead."
















